"""
code that uses Stack
"""


from stack import Stack


def list_stack(list_, st):



if __name__ == "__main__":
